package com.busManagement.exception;

public class UserDoesnotExistException extends RuntimeException {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public UserDoesnotExistException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

	public UserDoesnotExistException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
	
}
